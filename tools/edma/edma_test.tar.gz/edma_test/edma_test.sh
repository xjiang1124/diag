
echo 1024 > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
sleep 2
mkdir -p /dev/hugepages
sleep 2
mount -t hugetlbfs nodev /dev/hugepages

init_file=/nic/conf/gen/mpu_prog_info.json

if [ ! -f $init_file ]; then
sysinit.sh classic hw
echo "Waiting for $init_file to be available"
start=`date "+%s"`                                                                                                                                                    
while [ ! -f /nic/conf/gen/mpu_prog_info.json ]
do 
        sleep 2
done
end=`date "+%s"`                                                                                                                                                    
runtime=$((end-start))
echo "waited for $runtime seconds"
fi


edma_lib=`pwd`
export LD_LIBRARY_PATH=$edma_lib:$LD_LIBRARY_PATH
echo $LD_LIBRARY_PATH
./eth_dbgtool.bin edma_stress 65 4096 45 0 45 0 2 rdpad 100 5
